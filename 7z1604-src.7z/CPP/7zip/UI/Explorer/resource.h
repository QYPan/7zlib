#define IDS_CONTEXT_FOLDER              2320
#define IDS_CONTEXT_ARCHIVE             2321
#define IDS_CONTEXT_OPEN                2322
#define IDS_CONTEXT_EXTRACT             2323
#define IDS_CONTEXT_COMPRESS            2324
#define IDS_CONTEXT_TEST                2325
#define IDS_CONTEXT_EXTRACT_HERE        2326
#define IDS_CONTEXT_EXTRACT_TO          2327
#define IDS_CONTEXT_COMPRESS_TO         2328
#define IDS_CONTEXT_COMPRESS_EMAIL      2329
#define IDS_CONTEXT_COMPRESS_TO_EMAIL   2330

#define IDB_MENU_LOGO  190
