// StdAfx.h

#ifndef __STDAFX_H
#define __STDAFX_H

// #define _WIN32_WINNT 0x0400
#define _WIN32_WINNT 0x0500
#define WINVER _WIN32_WINNT

#include "../../../Common/Common.h"

// #include "../../../Common/MyWindows.h"

// #include <commctrl.h>
// #include <ShlObj.h>
// #include <shlwapi.h>

// #define printf(x) NO_PRINTF_(x)
// #define sprintf(x) NO_SPRINTF_(x)

#endif
