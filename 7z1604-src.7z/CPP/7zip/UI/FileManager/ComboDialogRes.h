#define IDD_COMBO   98

#define IDT_COMBO  100
#define IDC_COMBO  101
